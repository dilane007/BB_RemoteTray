Tsamp = 1/250E6;
simtime = 100;
