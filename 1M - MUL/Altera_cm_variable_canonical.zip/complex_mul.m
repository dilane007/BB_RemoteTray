delay = 8;

res = zeros(simtime, 1);
res_real = zeros(simtime,1);
res_imag = zeros(simtime,1);
for i=1:simtime
    data = data_I(i) + data_Q(i)*j;
    coef = coef_real(i) + coef_imag(i)*j;
    res(i) = data * coef;
    res_real(i) = real(res(i));
    res_imag(i) = imag(res(i));
end

error = 0;
for i=1:simtime-delay
    isequal = res_real(i) - res_I(i+delay);
    isequal = res_imag(i) - res_Q(i+delay) + isequal;
    if (isequal ~= 0)
        error = error + 1;
    end
end

 if (error>0)
    disp([' Fail ']);
 else
    disp([' PASSED : ' num2str(simtime(1)-delay+1)  ' identical values']);			
 end;
